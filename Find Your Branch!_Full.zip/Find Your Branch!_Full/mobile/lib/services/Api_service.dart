import 'dart:convert';
import 'package:http/http.dart' as http;

class ApiService {

  static const baseUrl =
      "http://127.0.0.1:8000";

  Future getBranches() async {

    final response =
        await http.get(
      Uri.parse(
        "$baseUrl/branches",
      ),
    );

    return jsonDecode(response.body);
  }
}
