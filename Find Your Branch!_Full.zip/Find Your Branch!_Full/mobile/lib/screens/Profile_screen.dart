import 'package:flutter/material.dart';

class ProfileScreen extends StatelessWidget {

  @override
  Widget build(BuildContext context) {

    return Scaffold(
      appBar: AppBar(
        title: const Text("Profile"),
      ),

      body: ListView(
        children: const [

          ListTile(
            title: Text(
              "Saved Branches",
            ),
          ),

          ListTile(
            title: Text(
              "Language Settings",
            ),
          ),

          ListTile(
            title: Text(
              "Notifications",
            ),
          ),
        ],
      ),
    );
  }
}
