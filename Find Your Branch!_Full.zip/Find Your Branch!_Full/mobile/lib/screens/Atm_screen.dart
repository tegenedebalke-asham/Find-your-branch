import 'package:flutter/material.dart';

class AtmScreen extends StatelessWidget {

  @override
  Widget build(BuildContext context) {

    return Scaffold(
      appBar: AppBar(
        title: const Text("ATM Locator"),
      ),

      body: ListView(
        children: const [

          ListTile(
            title: Text(
              "Awash ATM - Working",
            ),
          ),

          ListTile(
            title: Text(
              "Dashen ATM - Offline",
            ),
          ),
        ],
      ),
    );
  }
}
