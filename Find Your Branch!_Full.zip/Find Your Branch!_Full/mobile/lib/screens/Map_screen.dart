import 'package:flutter/material.dart';

class MapScreen extends StatelessWidget {

  @override
  Widget build(BuildContext context) {

    return Scaffold(
      appBar: AppBar(
        title: const Text(
          "Branch Map",
        ),
      ),

      body: const Center(
        child: Text(
          "Google Map Integration",
        ),
      ),
    );
  }
}
