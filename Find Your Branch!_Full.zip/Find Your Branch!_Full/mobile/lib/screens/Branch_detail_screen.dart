import 'package:flutter/material.dart';
import 'package:shared_preferences/shared_preferences.dart';
import '../models/branch.dart';
import '../widgets/custom_button.dart';
import '../constants/colors.dart';

class BranchDetailScreen extends StatefulWidget {
  final Branch branch;
  const BranchDetailScreen({super.key, required this.branch});

  @override
  State<BranchDetailScreen> createState() => _BranchDetailScreenState();
}

class _BranchDetailScreenState extends State<BranchDetailScreen> {
  bool isFavorite = false;

  @override
  void initState() {
    super.initState();
    _checkFavoriteStatus();
  }

  Future<void> _checkFavoriteStatus() async {
    final prefs = await SharedPreferences.getInstance();
    final favorites = prefs.getStringList('favorite_branches') ?? [];
    setState(() {
      isFavorite = favorites.contains('${widget.branch.bankName}|${widget.branch.branchName}');
    });
  }

  Future<void> _toggleFavorite() async {
    final prefs = await SharedPreferences.getInstance();
    final favorites = prefs.getStringList('favorite_branches') ?? [];
    final branchKey = '${widget.branch.bankName}|${widget.branch.branchName}';

    if (isFavorite) {
      favorites.remove(branchKey);
    } else {
      favorites.add(branchKey);
    }
    await prefs.setStringList('favorite_branches', favorites);
    setState(() => isFavorite = !isFavorite);
    ScaffoldMessenger.of(context).showSnackBar(
      SnackBar(
        content: Text(isFavorite ? 'Added to favorites' : 'Removed from favorites'),
        duration: const Duration(seconds: 2),
      ),
    );
  }

  @override
  Widget build(BuildContext context) {
    final branch = widget.branch;
    return Scaffold(
      appBar: AppBar(
        title: Text(branch.bankName),
        actions: [
          IconButton(
            icon: Icon(
              isFavorite ? Icons.favorite : Icons.favorite_border,
              color: isFavorite ? Colors.red : null,
            ),
            onPressed: _toggleFavorite,
          ),
        ],
      ),
      body: Padding(
        padding: const EdgeInsets.all(16.0),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            _buildInfoRow(Icons.account_balance, 'Bank', branch.bankName),
            _buildInfoRow(Icons.store, 'Branch', branch.branchName),
            _buildInfoRow(Icons.location_on, 'Address', branch.address),
            _buildInfoRow(Icons.phone, 'Phone', branch.phone),
            if (branch.city.isNotEmpty)
              _buildInfoRow(Icons.location_city, 'City', branch.city),
            _buildInfoRow(Icons.access_time, 'Working Hours', branch.workingHours),
            const Divider(height: 32),
            Row(
              children: [
                Icon(
                  branch.atmStatus.toLowerCase() == 'working'
                      ? Icons.check_circle
                      : Icons.cancel,
                  color: branch.atmStatus.toLowerCase() == 'working'
                      ? Colors.green
                      : Colors.red,
                ),
                const SizedBox(width: 8),
                Text(
                  'ATM Status: ${branch.atmStatus}',
                  style: TextStyle(
                    fontSize: 16,
                    fontWeight: FontWeight.bold,
                    color: branch.atmStatus.toLowerCase() == 'working'
                        ? Colors.green
                        : Colors.red,
                  ),
                ),
              ],
            ),
            const Spacer(),
            CustomButton(
              text: 'Get Directions',
              onPressed: () {
                ScaffoldMessenger.of(context).showSnackBar(
                  const SnackBar(content: Text('Directions feature coming soon!')),
                );
              },
            ),
          ],
        ),
      ),
    );
  }

  Widget _buildInfoRow(IconData icon, String label, String value) {
    return Padding(
      padding: const EdgeInsets.only(bottom: 12),
      child: Row(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Icon(icon, size: 20, color: AppColors.primary),
          const SizedBox(width: 12),
          Expanded(
            child: RichText(
              text: TextSpan(
                style: const TextStyle(color: Colors.black, fontSize: 14),
                children: [
                  TextSpan(
                    text: '$label: ',
                    style: const TextStyle(fontWeight: FontWeight.bold),
                  ),
                  TextSpan(text: value.isNotEmpty ? value : 'N/A'),
                ],
              ),
            ),
          ),
        ],
      ),
    );
  }
}
