import 'package:flutter/material.dart';
import 'map_screen.dart';
import 'atm_screen.dart';
import 'profile_screen.dart';

class HomeScreen extends StatefulWidget {
  @override
  State<HomeScreen> createState() =>
      _HomeScreenState();
}

class _HomeScreenState
    extends State<HomeScreen> {

  int currentIndex = 0;

  final screens = [
    HomeBody(),
    MapScreen(),
    AtmScreen(),
    ProfileScreen(),
  ];

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body: screens[currentIndex],

      bottomNavigationBar:
          BottomNavigationBar(
        currentIndex: currentIndex,

        onTap: (index) {
          setState(() {
            currentIndex = index;
          });
        },

        items: const [
          BottomNavigationBarItem(
            icon: Icon(Icons.home),
            label: "Home",
          ),

          BottomNavigationBarItem(
            icon: Icon(Icons.map),
            label: "Map",
          ),

          BottomNavigationBarItem(
            icon: Icon(Icons.atm),
            label: "ATM",
          ),

          BottomNavigationBarItem(
            icon: Icon(Icons.person),
            label: "Profile",
          ),
        ],
      ),
    );
  }
}

class HomeBody extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: const Text(
          "Find Your Branch!",
        ),
      ),

      body: ListView(
        children: const [

          ListTile(
            title: Text(
              "Commercial Bank - Bole",
            ),
            subtitle: Text(
              "ATM Working",
            ),
          ),

          ListTile(
            title: Text(
              "Hibret Bank - Kazanchis",
            ),
            subtitle: Text(
              "ATM Offline",
            ),
          ),
        ],
      ),
    );
  }
}
