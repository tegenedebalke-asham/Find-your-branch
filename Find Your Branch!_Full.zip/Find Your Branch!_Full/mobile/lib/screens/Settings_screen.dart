import 'package:flutter/material.dart';
import 'package:shared_preferences/shared_preferences.dart';
import '../constants/colors.dart';

class SettingsScreen extends StatefulWidget {
  const SettingsScreen({super.key});

  @override
  State<SettingsScreen> createState() => _SettingsScreenState();
}

class _SettingsScreenState extends State<SettingsScreen> {
  bool isEnglish = true;
  bool notificationsEnabled = true;

  @override
  void initState() {
    super.initState();
    _loadSettings();
  }

  Future<void> _loadSettings() async {
    final prefs = await SharedPreferences.getInstance();
    setState(() {
      isEnglish = prefs.getBool('isEnglish') ?? true;
      notificationsEnabled = prefs.getBool('notifications') ?? true;
    });
  }

  Future<void> _updateLanguage(bool value) async {
    final prefs = await SharedPreferences.getInstance();
    await prefs.setBool('isEnglish', value);
    setState(() => isEnglish = value);
    ScaffoldMessenger.of(context).showSnackBar(
      SnackBar(content: Text('Language changed to ${value ? "English" : "Amharic"}')),
    );
  }

  Future<void> _updateNotifications(bool value) async {
    final prefs = await SharedPreferences.getInstance();
    await prefs.setBool('notifications', value);
    setState(() => notificationsEnabled = value);
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: const Text('Settings')),
      body: ListView(
        padding: const EdgeInsets.all(16),
        children: [
          const Text(
            'Language',
            style: TextStyle(fontSize: 18, fontWeight: FontWeight.bold, color: AppColors.primary),
          ),
          const SizedBox(height: 8),
          SwitchListTile(
            title: Text(isEnglish ? 'English' : '????'),
            value: isEnglish,
            onChanged: _updateLanguage,
            activeColor: AppColors.primary,
          ),
          const Divider(),
          const Text(
            'Notifications',
            style: TextStyle(fontSize: 18, fontWeight: FontWeight.bold, color: AppColors.primary),
          ),
          const SizedBox(height: 8),
          SwitchListTile(
            title: const Text('Enable push notifications'),
            subtitle: const Text('Receive updates about branch/ATM status'),
            value: notificationsEnabled,
            onChanged: _updateNotifications,
            activeColor: AppColors.primary,
          ),
          const Divider(),
          const Text(
            'App Info',
            style: TextStyle(fontSize: 18, fontWeight: FontWeight.bold, color: AppColors.primary),
          ),
          const ListTile(
            title: Text('Find Your Branch!'),
            subtitle: Text('Version 1.0.0\nDeveloped by Tegene Debalke\nAsham Tech Solution'),
          ),
        ],
      ),
    );
  }
}
