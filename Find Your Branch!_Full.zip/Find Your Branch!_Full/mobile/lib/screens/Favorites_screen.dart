import 'package:flutter/material.dart';
import 'package:shared_preferences/shared_preferences.dart';
import '../models/branch.dart';
import '../widgets/branch_card.dart';

class FavoritesScreen extends StatefulWidget {
  const FavoritesScreen({super.key});

  @override
  State<FavoritesScreen> createState() => _FavoritesScreenState();
}

class _FavoritesScreenState extends State<FavoritesScreen> {
  List<Branch> allBranches = [];
  List<Branch> favoriteBranches = [];

  @override
  void initState() {
    super.initState();
    // Placeholder branch list � replace with your API data later
    allBranches = [
      Branch(
        bankName: 'Commercial Bank',
        branchName: 'Bole',
        address: 'Bole Road',
        phone: '0111-234567',
        atmStatus: 'Working',
        city: 'Addis Ababa',
        latitude: '9.0227',
        longitude: '38.7468',
        workingHours: '8:00 AM - 5:00 PM',
      ),
    ];
    _loadFavorites();
  }

  Future<void> _loadFavorites() async {
    final prefs = await SharedPreferences.getInstance();
    final keys = prefs.getStringList('favorite_branches') ?? [];
    setState(() {
      favoriteBranches = allBranches.where((b) {
        final branchKey = '${b.bankName}|${b.branchName}';
        return keys.contains(branchKey);
      }).toList();
    });
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: const Text('Favorites')),
      body: favoriteBranches.isEmpty
          ? const Center(
              child: Text(
                'No favorite branches yet.',
                style: TextStyle(fontSize: 16),
              ),
            )
          : ListView.builder(
              itemCount: favoriteBranches.length,
              itemBuilder: (context, index) {
                return BranchCard(branch: favoriteBranches[index]);
              },
            ),
    );
  }
}
