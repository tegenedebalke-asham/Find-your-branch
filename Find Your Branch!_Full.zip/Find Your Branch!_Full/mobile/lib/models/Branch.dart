class Branch {
  final String bankName;
  final String branchName;
  final String address;
  final String phone;
  final String atmStatus;
  final String city;
  final String latitude;
  final String longitude;
  final String workingHours;

  Branch({
    required this.bankName,
    required this.branchName,
    required this.address,
    required this.phone,
    required this.atmStatus,
    this.city = '',
    this.latitude = '',
    this.longitude = '',
    this.workingHours = '',
  });

  factory Branch.fromJson(Map<String, dynamic> json) {
    return Branch(
      bankName: json['bank_name'] ?? '',
      branchName: json['branch_name'] ?? '',
      address: json['address'] ?? '',
      phone: json['phone'] ?? '',
      atmStatus: json['atm_status'] ?? '',
      city: json['city'] ?? '',
      latitude: json['latitude']?.toString() ?? '',
      longitude: json['longitude']?.toString() ?? '',
      workingHours: json['working_hours'] ?? '',
    );
  }
}
