import 'package:flutter/material.dart';
import '../models/branch.dart';
import '../constants/colors.dart';

class AtmCard extends StatelessWidget {
  final Branch branch;
  const AtmCard({super.key, required this.branch});

  @override
  Widget build(BuildContext context) {
    bool isWorking = branch.atmStatus.toLowerCase() == 'working';
    return Card(
      margin: const EdgeInsets.symmetric(horizontal: 16, vertical: 6),
      shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(10)),
      elevation: 2,
      child: ListTile(
        leading: Icon(
          Icons.atm,
          color: isWorking ? Colors.green : Colors.red,
          size: 30,
        ),
        title: Text(branch.bankName),
        subtitle: Text(branch.address),
        trailing: Container(
          padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 6),
          decoration: BoxDecoration(
            color: isWorking ? Colors.green.withOpacity(0.1) : Colors.red.withOpacity(0.1),
            borderRadius: BorderRadius.circular(20),
            border: Border.all(
              color: isWorking ? Colors.green : Colors.red,
              width: 1,
            ),
          ),
          child: Text(
            isWorking ? 'Working' : 'Offline',
            style: TextStyle(
              color: isWorking ? Colors.green : Colors.red,
              fontWeight: FontWeight.bold,
              fontSize: 12,
            ),
          ),
        ),
      ),
    );
  }
}
