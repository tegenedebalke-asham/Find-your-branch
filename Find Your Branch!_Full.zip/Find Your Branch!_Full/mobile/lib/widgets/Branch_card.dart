import 'package:flutter/material.dart';
import '../models/branch.dart';
import '../screens/branch_detail_screen.dart';
import '../constants/colors.dart';

class BranchCard extends StatelessWidget {
  final Branch branch;
  const BranchCard({super.key, required this.branch});

  @override
  Widget build(BuildContext context) {
    return Card(
      margin: const EdgeInsets.symmetric(horizontal: 16, vertical: 6),
      shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(10)),
      elevation: 3,
      child: ListTile(
        leading: CircleAvatar(
          backgroundColor: AppColors.primary,
          child: Text(
            branch.bankName.isNotEmpty ? branch.bankName[0].toUpperCase() : 'B',
            style: const TextStyle(color: Colors.white, fontWeight: FontWeight.bold),
          ),
        ),
        title: Text(
          branch.bankName,
          style: const TextStyle(fontWeight: FontWeight.bold),
        ),
        subtitle: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Text(branch.branchName),
            const SizedBox(height: 4),
            Row(
              children: [
                Icon(
                  branch.atmStatus.toLowerCase() == 'working'
                      ? Icons.check_circle
                      : Icons.cancel,
                  size: 16,
                  color: branch.atmStatus.toLowerCase() == 'working'
                      ? Colors.green
                      : Colors.red,
                ),
                const SizedBox(width: 4),
                Text(
                  'ATM ${branch.atmStatus}',
                  style: TextStyle(
                    fontSize: 12,
                    color: branch.atmStatus.toLowerCase() == 'working'
                        ? Colors.green
                        : Colors.red,
                  ),
                ),
              ],
            ),
          ],
        ),
        trailing: const Icon(Icons.chevron_right),
        onTap: () {
          Navigator.push(
            context,
            MaterialPageRoute(
              builder: (_) => BranchDetailScreen(branch: branch),
            ),
          );
        },
      ),
    );
  }
}
