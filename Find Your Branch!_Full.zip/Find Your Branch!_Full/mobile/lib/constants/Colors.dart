import 'package:flutter/material.dart';

class AppColors {
  static const Color primary = Color(0xFF4CAF50);
  static const Color secondary = Color(0xFFFFC107);
  static const Color dark = Color(0xFF000000);
  static const Color white = Color(0xFFFFFFFF);
}
